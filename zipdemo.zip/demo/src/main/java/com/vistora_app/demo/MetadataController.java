package com.vistora_app.demo;

import com.vistora_app.demo.config;
import com.vistora_app.demo.service;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/metadata")
public class MetadataController {

    @Autowired
    private service metadataService;

    @PostConstruct
    public void init() throws IOException, SQLException {
        config config1 = config.load("src/main/resources/static/db.json");
        metadataService.connect(config1);
    }

    @GetMapping("/tables")
    public List<String> listTables() throws SQLException {
        return metadataService.listTables();
    }

    @GetMapping("/table/{name}")
    public Map<String, Object> getTableMetadata(@PathVariable String name) throws SQLException {
        return metadataService.getTableMetadata(name);
    }
}
