package com.vistora_app.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;

public class config {
    public String url;
    public String username;
    public String password;

    public static config load(String path) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(new File(path), config.class);
    }
}
