package com.vistora_app.demo;

import com.vistora_app.demo.config;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.*;

@Service
public class service {
    private Connection connection;

    public void connect(config config) throws SQLException {
        this.connection = DriverManager.getConnection(config.url, config.username, config.password);
    }

    public List<String> listTables() throws SQLException {
        List<String> tables = new ArrayList<>();
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet rs = metaData.getTables(null, null, "%", new String[]{"TABLE"});
        while (rs.next()) {
            tables.add(rs.getString("TABLE_NAME"));
        }
        return tables;
    }

    public Map<String, Object> getTableMetadata(String tableName) throws SQLException {
        Map<String, Object> tableInfo = new LinkedHashMap<>();
        DatabaseMetaData metaData = connection.getMetaData();

        List<Map<String, String>> columns = new ArrayList<>();
        ResultSet rsColumns = metaData.getColumns(null, null, tableName, null);
        while (rsColumns.next()) {
            Map<String, String> col = new HashMap<>();
            col.put("name", rsColumns.getString("COLUMN_NAME"));
            col.put("type", rsColumns.getString("TYPE_NAME"));
            columns.add(col);
        }
        tableInfo.put("columns", columns);

        List<String> primaryKeys = new ArrayList<>();
        ResultSet rsPK = metaData.getPrimaryKeys(null, null, tableName);
        while (rsPK.next()) {
            primaryKeys.add(rsPK.getString("COLUMN_NAME"));
        }
        tableInfo.put("primaryKeys", primaryKeys);

        List<Map<String, String>> foreignKeys = new ArrayList<>();
        ResultSet rsFK = metaData.getImportedKeys(null, null, tableName);
        while (rsFK.next()) {
            Map<String, String> fk = new HashMap<>();
            fk.put("fkColumn", rsFK.getString("FKCOLUMN_NAME"));
            fk.put("pkTable", rsFK.getString("PKTABLE_NAME"));
            fk.put("pkColumn", rsFK.getString("PKCOLUMN_NAME"));
            foreignKeys.add(fk);
        }
        tableInfo.put("foreignKeys", foreignKeys);

        return tableInfo;
    }
}
